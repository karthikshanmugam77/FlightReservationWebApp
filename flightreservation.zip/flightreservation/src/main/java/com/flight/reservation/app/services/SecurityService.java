package com.flight.reservation.app.services;

public interface SecurityService {
	
	boolean login(String username, String password);

}
