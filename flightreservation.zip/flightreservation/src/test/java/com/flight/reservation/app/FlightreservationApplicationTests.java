package com.flight.reservation.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightreservationApplicationTests {

	@Test
	void contextLoads() {
	}

}
